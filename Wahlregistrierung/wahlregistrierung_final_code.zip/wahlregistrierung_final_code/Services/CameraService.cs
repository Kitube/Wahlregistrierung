using System.Drawing;
using OpenCvSharp;
using OpenCvSharp.Extensions;

namespace Wahlregistrierung.Services
{
    public class CameraService
    {
        private VideoCapture? capture;

        public bool StartCamera(int cameraIndex = 0)
        {
            StopCamera();

            capture = new VideoCapture(cameraIndex);
            if (!capture.IsOpened())
            {
                StopCamera();
                return false;
            }

            return true;
        }

        public Bitmap? GetFrame()
        {
            if (capture == null || !capture.IsOpened())
                return null;

            using var frame = new Mat();
            capture.Read(frame);

            if (frame.Empty())
                return null;

            return BitmapConverter.ToBitmap(frame);
        }

        public void StopCamera()
        {
            capture?.Release();
            capture?.Dispose();
            capture = null;
        }
    }
}
