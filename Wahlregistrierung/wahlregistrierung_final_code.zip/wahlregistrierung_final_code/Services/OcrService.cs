using System.Drawing;
using System.Linq;
using OpenCvSharp;
using OpenCvSharp.Extensions;
using Tesseract;
using Wahlregistrierung.Config;

namespace Wahlregistrierung.Services
{
    public class OcrService
    {
        public string ReadIdFromImage(Bitmap frame, AppSettings settings)
        {
            using Bitmap processed = CropAndPreprocess(frame, settings);

            using var engine = new TesseractEngine(AppPaths.TessdataDirectory, "eng", EngineMode.Default);
            engine.SetVariable("tessedit_char_whitelist", "0123456789");
            engine.DefaultPageSegMode = PageSegMode.SingleLine;

            using var pix = PixConverter.ToPix(processed);
            using var page = engine.Process(pix);

            string raw = page.GetText() ?? string.Empty;
            return new string(raw.Where(char.IsDigit).ToArray());
        }

        private Bitmap CropAndPreprocess(Bitmap source, AppSettings settings)
        {
            using var sourceMat = BitmapConverter.ToMat(source);

            int cropWidth = (int)(sourceMat.Width * settings.CropWidthRatio);
            int cropHeight = (int)(sourceMat.Height * settings.CropHeightRatio);

            if (cropWidth <= 0) cropWidth = sourceMat.Width;
            if (cropHeight <= 0) cropHeight = sourceMat.Height;

            int x = (sourceMat.Width - cropWidth) / 2;
            int y = (sourceMat.Height - cropHeight) / 2;
            x = x < 0 ? 0 : x;
            y = y < 0 ? 0 : y;
            if (x + cropWidth > sourceMat.Width) cropWidth = sourceMat.Width - x;
            if (y + cropHeight > sourceMat.Height) cropHeight = sourceMat.Height - y;

            var roi = new Rect(x, y, cropWidth, cropHeight);

            using var cropped = new Mat(sourceMat, roi);
            using var gray = new Mat();
            using var blurred = new Mat();
            using var thresholded = new Mat();

            Cv2.CvtColor(cropped, gray, ColorConversionCodes.BGR2GRAY);
            Cv2.GaussianBlur(gray, blurred, new OpenCvSharp.Size(3, 3), 0);
            Cv2.Threshold(blurred, thresholded, 0, 255, ThresholdTypes.Binary | ThresholdTypes.Otsu);

            return BitmapConverter.ToBitmap(thresholded);
        }
    }
}
