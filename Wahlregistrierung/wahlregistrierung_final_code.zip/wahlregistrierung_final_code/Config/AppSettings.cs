using Wahlregistrierung.Enums;

namespace Wahlregistrierung.Config
{
    public class AppSettings
    {
        public CameraScanMode CameraMode { get; set; } = CameraScanMode.ManualTrigger;
        public int CameraIndex { get; set; } = 0;
        public int ScanIntervalMs { get; set; } = 180;
        public int CooldownMs { get; set; } = 1500;
        public int ConsecutiveFramesRequired { get; set; } = 3;
        public double CropWidthRatio { get; set; } = 0.70;
        public double CropHeightRatio { get; set; } = 0.20;

        public static AppSettings CreateDefault()
        {
            return new AppSettings();
        }
    }
}
